/* eslint-disable @lwc/lwc/no-api-reassignments */ //component needs to reflect internal state changes via public property
/* eslint-disable @lwc/lwc/no-async-operation */
import { LightningElement, track, api } from "lwc";  

import findRecords from "@salesforce/apex/LwcLookupGenericController.findRecords";  

import LWC_06_LOOKUP_ASSISTIVE_RECORD from '@salesforce/label/c.LWC_06_LOOKUP_ASSISTIVE_RECORD';
import LWC_06_LOOKUP_ASSISTIVE_RMV_RECORD from '@salesforce/label/c.LWC_06_LOOKUP_ASSISTIVE_RMV_RECORD';
import LWC_06_LOOKUP_ASSISTIVE_NO_RECORDS from '@salesforce/label/c.LWC_06_LOOKUP_ASSISTIVE_NO_RECORDS';
import LWC_06_LOOKUP_ASSISTIVE_RMV_OPTION from '@salesforce/label/c.LWC_06_LOOKUP_ASSISTIVE_RMV_OPTION';
import labelCompleteField from '@salesforce/label/c.LWC_06_LOOKUP_ASSISTIVE_COMPLETE_FIELD';

const NO_RECORDS_FOUND = LWC_06_LOOKUP_ASSISTIVE_NO_RECORDS;

export default class Lwc06lookupGeneric extends LightningElement {  
    @track recordsList;  
    @track selectedRecords = [];
    @track searchKey = "";  
    lastSearchKey = '';
    @track message;  
    @track searchOptions = [];
    @track timeout;
    displayPicklistValues = false;

    @api selectedValue;  
    @api selectedRecordId;  
    @api objectApiName;  
    @api iconName;  
    @api isDisabledSearch;  
    @api placeHolder;
    @api fieldToReturnAsLabel;
    @api filters;
    @api orFilters;
    @api listFilters;
    @api isReturnedFieldGroupable = false;
    @api objectFieldApiName;
    @api otherFieldsToReturn;
    @api additionalFieldsToDisplay;
    @api isMultipleSelectedRecordsEnabled = false;
    selectedRecord;

    @api isInputDisabled = false;

    @api isRequired = false;
    showErrorMsg = false;

    label = {
        LWC_06_LOOKUP_ASSISTIVE_RECORD,
        LWC_06_LOOKUP_ASSISTIVE_RMV_RECORD,
        LWC_06_LOOKUP_ASSISTIVE_RMV_OPTION,
        labelCompleteField
    };

    get borderClass() {
        return this.showErrorMsg === true ? 'slds-input slds-combobox__input error-border' : 'slds-input slds-combobox__input';
    }

    onLeave() {  
        setTimeout(() => {  
            this.displayPicklistValues = false;
        },
        300);  
    }

    onFocus() {
        this.searchKey ||= this.lastSearchKey;
        this.displayPicklistValues = true;
    }    

    onRecordSelection(event) {  
        const selectedId = event.currentTarget.dataset.key;
        this.selectedRecord = this.recordsList?.find(element => element.Id === selectedId);
        this.lastSearchKey = this.searchKey;
        
        if (this.isMultipleSelectedRecordsEnabled) {
            if (this.selectedRecord && !this.selectedRecords.some(rec => rec.Id === selectedId)) {
                this.selectedRecords = [...this.selectedRecords, this.selectedRecord];

            }
            this.displayPicklistValues = false;   
        } else {
            this.selectedRecordId = this.selectedRecord?.Id;
            this.selectedValue = event.currentTarget.dataset.name;
        }

        this.dispatchRecordSelectionEvent();
    }

    removePill(event) {
        const recordId = event.currentTarget.dataset.id;
        this.selectedRecords = this.selectedRecords.filter(rec => rec.Id !== recordId);
        this.dispatchRecordSelectionEvent();
    }

    handleKeyChange(event) {  
        clearTimeout(this.timeout);
        this.searchKey = event.target.value.trim();  
        if(this.searchKey !== "") {
            this.timeout = setTimeout(this.getLookupResult.bind(this), 500);
        } else {
            this.recordsList = [];
            this.message = "";
        }
    }

    @api removeRecordOnLookup() {  
        this.searchKey = "";  
        this.lastSearchKey = "";
        this.selectedValue = null;  
        this.selectedRecordId = null;  
        this.recordsList = null;  
        this.selectedRecord = null;
        this.dispatchRecordSelectionEvent();  
    }

    getLookupResult() {  
        findRecords({ 
            searchKey: this.searchKey,
            objectName: this.objectApiName,
            fieldToReturn: this.fieldToReturnAsLabel,
            filters: this.filters,
            listFilters: this.listFilters,
            isFieldGroupable: this.isReturnedFieldGroupable,
            otherFieldsToReturn: this.otherFieldsToReturn,
            orFilters: this.orFilters,
            additionalFieldsToDisplay: this.additionalFieldsToDisplay ?? null
        })  
        .then((result) => {  
            if (result.length) {
                this.recordsList = result.map(record => {
                    let newRecord = { ...record, name: record[this.fieldToReturnAsLabel] };
                    if (this.additionalFieldsToDisplay) {
                        const fieldsToDisplayAsPicklistValue = this.additionalFieldsToDisplay.map(field => newRecord[field]).join(' - ');
                        newRecord.fieldsToDisplayAsPicklistValue = fieldsToDisplayAsPicklistValue;
                    }
                    return newRecord;
                });
                this.message = "";
            } else {
                this.recordsList = [];
                this.message = NO_RECORDS_FOUND;
            }
        }).catch((error) => {
            this.error = error;  
            this.recordsList = undefined;  
        });  
    }  

    dispatchRecordSelectionEvent() {
        this.dispatchEvent(new CustomEvent('recordselection', { 
            detail: this.isMultipleSelectedRecordsEnabled ? 
                { selectedRecords: this.selectedRecords } : 
                { 
                    selectedRecordId: this.selectedRecordId, 
                    selectedValue: this.selectedValue,
                    objectFieldApiName: this.objectApiName,
                    selectedRecord: this.selectedRecord
                }
        }));
    }   

    @api isInputValid() {
        let isValid = true;
        this.showErrorMsg = false;

        if(this.isRequired == true && !this.selectedValue) {
            isValid = false;   
            this.showErrorMsg = true;
        }
        
        return isValid;
    } 
}  